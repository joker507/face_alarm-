# coding=UTF-8
import requests
from bs4 import BeautifulSoup
def CourseTable(x):
    lt=''
    DataLogin={
    'username':'*',#填充这里
    'password':'*',
    'warn':'true',
    'lt':lt,
    'execution':'e1s1',
    '_eventId':'submit',
    'submit':'登录',
    }#登录数据
    HeaderLogin={
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36',
    }#登录头
    s=requests.Session()
    urlLogin='https://cas.gzhu.edu.cn/cas_server/login'
    r=s.get(urlLogin,headers=HeaderLogin)
    r.raise_for_status ()
    r.encoding = r.apparent_encoding
    TheText=r.text
    #开始分析出lT
    soup = BeautifulSoup(TheText,features="lxml")
    tag=soup.div.find_all(value=True)
    lt=tag[4]['value']#储存lt
    DataLogin['lt']=lt
    r=s.post(url=urlLogin,headers=HeaderLogin,data=DataLogin)#模拟登陆
    DataTable={
    'xnm':'2019',
    'xqm':'3',
    }#课表所需的data
    need = s.post(url='http://jwxt.gzhu.edu.cn/sso/lyiotlogin')#模拟登陆
    need =s.post(url='http://jwxt.gzhu.edu.cn/jwglxt/kbcx/xskbcx_cxXsKb.html?gnmkdm=N253508',data=DataTable)#查询课表
    FullList=need.json()['kbList']
    temp = ''
    sum=''
    for course in FullList:
        if(course['xqjmc']==x):
            if(temp==str(course['kcmc'])):
                break
            else:
                temp=str(course['kcmc'])
                sum=str(course['kcmc'])+sum
    return sum
if (__name__=='__main__'):
    CourseTable('星期一')