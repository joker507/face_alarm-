# coding=UTF-8
import requests
import baidu
import spider
def forecast():
    a='广州'
    web = requests.get('http://wthrcdn.etouch.cn/weather_mini?city='+a)
    web=web.json()
    data=web['data']['forecast'][0]
    day=data['date']
    temp1=data['high']
    temp2=data['low']
    type=data['type']
    print(day[-3:])
    text=a +day +temp1 + temp2+ type+'今天要上的课是'+str(spider.CourseTable(day[-3:]))
    baidu.sound(text)
if(__name__=='__main__'):
    forecast()